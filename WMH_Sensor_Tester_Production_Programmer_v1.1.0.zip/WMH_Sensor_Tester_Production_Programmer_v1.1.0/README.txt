WMH RACING SENSOR TESTER PRODUCTION PROGRAMMER
Version 1.1.0

WHAT THIS FILE DOES
  WMH_Sensor_Tester_Programmer_v1.1.0.exe is self-contained.
  It embeds:
    - Sensor Tester firmware v0.1.9
    - AVRDUDE 8.0 Arduino build
    - AVRDUDE configuration supporting ATmega328PB and AVRISP mkII

TARGET
  MCU:        ATmega328PB
  Clock:      Internal 8 MHz
  Programmer: AVRISP mkII / Waveshare USB AVRISP XPII
  Board power: Sensor Tester MUST be powered from USB-C.
  Programmer VCC is target-voltage sense only.

PRODUCTION SETTINGS
  LFUSE:  0xE2
  HFUSE:  0xD7
  EFUSE:  0xF5
  LOCK:   0xFF

PROGRAMMING FLOW
  1. Contact target at 100 kHz ISP for a factory-fresh MCU.
  2. Verify ATmega328PB signature.
  3. Write production fuse bytes.
  4. Verify fuse bytes.
  5. Program Sensor Tester v0.1.9 at 500 kHz ISP.
  6. Verify flash.
  7. Show PASS or FAIL.

BUILDER WORKFLOW
  1. Connect the Waveshare USB AVRISP XPII / AVRISP mkII to the Windows PC.
  2. Power the Sensor Tester board from USB-C.
  3. Double-click WMH_Sensor_Tester_Programmer_v1.1.0.exe.
  4. Hold the pogo fixture firmly against all six J5 pads.
  5. Press ENTER.
  6. Keep the fixture in place until PASS or FAIL appears.
  7. Remove the board. Press ENTER again for the next board.

J5 SIGNAL MAP
  J5-1 MOSI
  J5-2 MISO
  J5-3 SCK
  J5-4 RESET
  J5-5 VCC target sense
  J5-6 GND

WINDOWS DRIVER
  The PC still needs a Windows driver compatible with the AVRISP mkII/XPII and
  AVRDUDE, just as the development PC does. Arduino IDE does not need to be
  installed.

LOG FILE
  SensorTesterProgrammer.log is created next to the EXE and contains the full
  AVRDUDE output for troubleshooting.

FIRMWARE SHA256
  730BAE4D4D04303DEDA44661F152665E73AD139BAF1A9AE2330561FA10FB26E7

PROGRAMMER EXE SHA256
  DF4250901C6D5F133F0D0F8A6AF895F7EC53B80435F22A4679A477042172EB0A
